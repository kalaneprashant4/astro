import os
import openai

async def ai1(message):
    if message.text == '/ai':
        await message.reply("<code>Hey How Can I Help You</code>", parse_mode='html')
    else:
        response = openai.Completion.create(
            model="text-davinci-003",
            prompt=message.text,
            temperature=0.5,
            max_tokens=1024,
            top_p=1,
            frequency_penalty=0.0,
            presence_penalty=0.0,
        )
        await message.reply(response.choices[0].text, parse_mode='html')
