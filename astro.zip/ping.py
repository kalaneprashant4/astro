import asyncio
import time

async def ping1(message):
    start_time = time.time()
    await asyncio.sleep(0.5)
    end_time = time.time()
    ping_time = round((end_time - start_time) * 94, 2)  # Convert to milliseconds and round to 2 decimal places

    await message.answer(f'''
<b>Ping</b> : <code>{ping_time}</code> ms
''', parse_mode="html")