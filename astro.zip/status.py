import datetime

async def status1(message):
    with open('registered_users.txt', 'r') as file:
        line_count = sum(1 for line in file)
    
    today = datetime.date.today()
    day_name = today.strftime('%A')
    
    await message.answer(f'''
𝗕𝗢𝗧 𝗦𝗧𝗔𝗧𝗨𝗦 : 𝗔𝗖𝗧𝗜𝗩𝗘 ✅
𝗗𝗔𝗧𝗘 𝗧𝗢𝗗𝗔𝗬 : <code>{day_name}, {today}</code>
𝗧𝗢𝗧𝗔𝗟 𝗔𝗖𝗧𝗜𝗩𝗘 𝗨𝗦𝗘𝗥𝗦 : <code>{line_count}</code>
𝗖𝗛𝗘𝗖𝗞𝗘𝗗 𝗕𝗬 : <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a>
''', parse_mode="html")