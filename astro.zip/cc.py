import re
import logging
import requests

SK_KEY = "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"

async def get_token(cc, mes, ano, cvv):
    url = "https://api.stripe.com/v1/payment_methods"
    headers = {'Authorization': f'Bearer {SK_KEY}'}
    data = {
        'type': 'card',
        'card[number]': cc,
        'card[exp_month]': mes,
        'card[exp_year]': ano,
        'card[cvc]': cvv,
        'billing_details[address][line1]': '36',
        'billing_details[address][line2]': 'Regent Street',
        'billing_details[address][city]': 'Jamestown',
        'billing_details[address][postal_code]': '14701',
        'billing_details[address][state]': 'New York',
        'billing_details[address][country]': 'US',
        'billing_details[email]': 'bisnuray942@gmail.com',
        'billing_details[name]': 'Astroboy Mittal'
    }
    response = requests.post(url, data=data, headers=headers)
    result1 = response.json()
    token = result1.get('id')
    msg1 = result1.get('message')
    
    return result1, token, msg1

async def request_charge(token):
    url = "https://api.stripe.com/v1/payment_intents"
    headers = {'Authorization': f'Bearer {SK_KEY}'}
    data = {
        'amount': '100',
        'currency': 'usd',
        'payment_method_types[]': 'card',
        'description': 'AstroHQ Donation',
        'payment_method': token,
        'confirm': 'true',
        'off_session': 'true'
    }
    response = requests.post(url, data=data, headers=headers)
    result2 = response.json()
    msg2 = result2.get('message')
    rcp = result2.get('receipt_url')
    
    return result2, msg2, rcp

async def cc1(message, bot):
    xtp = message.text.split()
    lista = xtp[1]
    cc_split = lista.split('|')
    cc = cc_split[0]
    mes = cc_split[1]
    ano = cc_split[2]
    cvv = cc_split[3]
    amt = 1
    result1, token, msg1 = await get_token(cc, mes, ano, cvv)
    result2, msg2, rcp = await request_charge(token)
    
    if 'seller_message' in result2 and result2['seller_message'] == 'Payment complete.':
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: CVV Matched ✅</b>\n"
            f"<b>➤ Result: Successfully Charged ${amt} ✅</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif 'insufficient_funds' in result2:
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: CVV Matched ✅</b>\n"
            f"<b>➤ Result: Insufficient Funds</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif 'card_error_authentication_required' in result1 or 'card_error_authentication_required' in result2:
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: CVV Matched ✅</b>\n"
            f"<b>➤ Result: 3D Card</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif 'cvc_check' in result2 and result2['cvc_check'] == 'pass':
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: CVV Matched ✅</b>\n"
            f"<b>➤ Result: Payment Cannot Be Completed</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif 'incorrect_cvc' in result2 or 'incorrect_cvc' in result1:
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: CCN Matched ✅</b>\n"
            f"<b>➤ Result: CVV MISMATCH</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif 'transaction_not_allowed' in result1 or 'transaction_not_allowed' in result2:
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: CVV Matched ✅</b>\n"
            f"<b>➤ Result: Transaction Not Allowed</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif 'fraudulent' in result1 or 'fraudulent' in result2:
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: Fraudulent</b>\n"
            f"<b>➤ Result: Declined ❌</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif 'expired_card' in result1 or 'expired_card' in result2:
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: Expired Card</b>\n"
            f"<b>➤ Result: Declined ❌</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif 'generic_declined' in result1 or 'generic_declined' in result2:
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: Generic Declined</b>\n"
            f"<b>➤ Result: Declined ❌</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif 'card_declined' in result1 or 'payment_intent_unexpected_state' in result2:
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: Card Declined</b>\n"
            f"<b>➤ Result: Declined ❌</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif 'do_not_honor' in result1 or 'do_not_honor' in result2:
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: Do Not Honor</b>\n"
            f"<b>➤ Result: Declined ❌</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif 'rate_limit' in result1 or 'rate_limit' in result2:
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: SK IS AT RATE LIMIT</b>\n"
            f"<b>➤ Result: Declined ❌</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")
      
    elif msg1 is not None and 'Your card was declined.' in msg1 or msg2 is not None and 'Your card was declined.' in msg2:
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: Generic Declined</b>\n"
            f"<b>➤ Result: Declined ❌</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>", parse_mode="html")

    elif 'message' in result1 and result1['message'] == 'Your card number is incorrect.':
        await message.reply(
            f"<b>Card: <code>{lista}</code></b>\n"
            f"<b>➤ Status: Card Number Is Incorrect</b>\n"
            f"<b>➤ Result: Declined ❌</b>\n"
            f"<b>➤ Gateway: Stripe Charge ${amt}</b>\n\n"
            f"<b>Bot By: Astroboy</b>" , parse_mode="html")
    else:
        await message.reply("<b>Unknown Error</b>", parse_mode="html")