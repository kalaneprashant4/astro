import requests
import json

async def bin1(message):
    if len(message.text.split()) >= 2:
        bin = message.text.split()[1]
    elif message.reply_to_message and message.reply_to_message.text:
        bin = message.reply_to_message.text
    else:
        await message.answer("<b>NO BIN PROVIDED</b>\n<b>USE /bin [ YOUR BIN NUMBER ]</b>", parse_mode="html")
        return
    
    session = requests.session()
    bin_info = session.get(f"https://lookup.binlist.net/{bin}").json()

    try:
        brand = bin_info["scheme"].upper()
    except KeyError:
        brand = "N/A"
    try:
        card_type = bin_info["type"].upper()
    except KeyError:
        card_type = "N/A"
    try:
        level = bin_info["brand"].upper()
    except KeyError:
        level = "N/A"
    try:
        bank_data = bin_info["bank"]
    except KeyError:
        bank_data = "N/A"
    try:
        bank = bank_data["name"].upper()
    except KeyError:
        bank = "N/A"
    try:
        country_data = bin_info["country"]
    except KeyError:
        country_data = "N/A"
    try:
        country = country_data["name"].upper()
    except KeyError:
        country = "N/A"
    try:
        flag = country_data["emoji"]
    except KeyError:
        flag = "N/A"
    try:
        currency = country_data["currency"].upper()
    except KeyError:
        currency = "N/A"

    await message.answer(f'''
<b>Valid Bin ✅</b>

<b>Bin :</b> <code>{bin}</code>

<b>Bin Info :</b> {brand} - {card_type} - {level}
<b>Bank :</b> {bank}
<b>Currency :</b> {currency}
<b>Country :</b> {country} {flag}

<b>Checked By</b> ➺ <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a>
<b>Bot Made By</b> ➺ <a href="tg://user?id=1408470031"><b>𝙰𝚂𝚃𝚁𝙾𝙱𝙾𝚈</b></a>
    ''', parse_mode="html")
