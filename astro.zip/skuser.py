import re
import requests
import time

async def on_apiskuser(message):
    astro = message.text.split()
    sk_key = None
    if len(astro) == 2:
        sk_key = astro[1]
    elif message.reply_to_message and message.reply_to_message.text:
        sk_find = message.reply_to_message.text
        sk_key = re.search(r"sk_live_[a-zA-Z0-9]+", sk_find)
    else:
        await message.reply("<b>NO SK KEY PROVIDED</b>\n<b>USE /sk [ YOUR SK KEY ]</b>", parse_mode="html")

    if sk_key is not None:
        headers = {
            'Authorization': f'Bearer {sk_key}',
            'Content-Type': 'application/x-www-form-urlencoded',
        }
        params = {
            'limit': 15,
        }

        response = requests.get('https://api.stripe.com/v1/charges', headers=headers, params=params)
        charges = response.json()
        charge_count = len(charges['data'])

        lists = []
        skdegcount = sk_key.split('_')[2]
        ass = skdegcount[:5]
        boobs = skdegcount[-5:]
        for i, charge in enumerate(charges['data'], 1):
            description = charge.get('description', 'No description')
            lists.append(f'<code>{description}</code>')
        skusers = "\n".join(lists) + f'\n\n𝗨𝘀𝗲𝗿𝘀 ➺  <code>{charge_count}</code>\n𝗦𝗞 ➺  <code>sk_live_{ass}•𝐀𝐒𝐓𝐑𝐎•{boobs}</code>'

        msg = await message.reply(skusers, parse_mode="html")

        while True:
            response = requests.get('https://api.stripe.com/v1/charges', headers=headers, params=params)
            charges = response.json()
            charge_count = len(charges['data'])

            lists = []
            skdegcount = sk_key.split('_')[2]
            ass = skdegcount[:5]
            boobs = skdegcount[-5:]
            for i, charge in enumerate(charges['data'], 1):
                description = charge.get('description', 'No description')
                lists.append(f'<code>{description}</code>')
            skusers = "\n".join(lists) + f'\n\n𝗨𝘀𝗲𝗿𝘀 ➺  <code>{charge_count}</code>\n𝗦𝗞 ➺  <code>sk_live_{ass}•𝐀𝐒𝐓𝐑𝐎•{boobs}</code>'

            await msg.edit_text(skusers, parse_mode="html")

            # Wait for 5 seconds before updating the message
            time.sleep(5)
