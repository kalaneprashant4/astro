import logging
import openai
from start import start1
from id import id1
from ai import ai1
from cmd import cmd1
from sk import sk1
from msk import msk1
from ipcheck import ip1
from ping import ping1
from skuser import on_apiskuser
from bin import bin1
from ccscrap import scrape1
from ccgen import generate_cc
from rnd import rnd1
from status import status1
from cc import cc1
from telethon.sync import TelegramClient
from aiogram import Bot, Dispatcher, executor, types
from config import botapihash, botapiid, openaiapi, PREFIX, tgbottok, adminid

api_id = botapiid
api_hash = botapihash
client = TelegramClient('client', api_id, api_hash)

logging.basicConfig(level=logging.INFO)

BOT_TOKEN = tgbottok
openai.api_key = openaiapi
admin_id = adminid

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)

def is_user_registered(user_id):
    with open("registered_users.txt", "r") as f:
        registered_users = f.read().splitlines()

    if str(user_id) in registered_users:
        return True
    else:
        return False

def register_user(user_id):
    with open("registered_users.txt", "a") as f:
        f.write(f"{user_id}\n")

@dp.message_handler(commands=['start'], commands_prefix=PREFIX)
async def handle_start_cmd(message: types.Message):
  await start1(message)


@dp.message_handler(commands=['register'], commands_prefix=PREFIX)
async def handle_register_cmd(message: types.Message):
    user_id = message.from_user.id
    if is_user_registered(user_id):
        await message.reply("𝗨𝗦𝗘𝗥 𝗔𝗟𝗥𝗘𝗔𝗗𝗬 𝗥𝗘𝗚𝗜𝗦𝗧𝗘𝗥𝗘𝗗 ⚠️\n𝗧𝗬𝗣𝗘 /cmds 𝗧𝗢 𝗞𝗡𝗢𝗪 𝗠𝗬 𝗔𝗕𝗜𝗟𝗜𝗧𝗬", parse_mode='html')
    else:
        register_user(user_id)
        await message.reply("𝗨𝗦𝗘𝗥 𝗥𝗘𝗚𝗜𝗦𝗧𝗘𝗥𝗘𝗗 𝗦𝗨𝗖𝗖𝗘𝗦𝗦𝗙𝗨𝗟𝗟𝗬 ✅")

async def check_if_registered(message: types.Message):
    user_id = message.from_user.id
    if not is_user_registered(user_id):
        await message.reply("𝗬𝗢𝗨 𝗔𝗥𝗘 𝗡𝗢𝗧 𝗥𝗘𝗚𝗜𝗦𝗧𝗘𝗥𝗗 ⚠️\n𝗣𝗟𝗘𝗔𝗦𝗘 𝗥𝗘𝗚𝗜𝗦𝗧𝗘𝗥 𝗨𝗦𝗜𝗡𝗚 /register 𝗖𝗢𝗠𝗠𝗔𝗡𝗗", parse_mode='html')
        return False
    return True

@dp.message_handler(commands=['brod'], commands_prefix=PREFIX)
async def handle_brod_cmd(message: types.Message):
  if await check_if_registered(message):
    if message.from_user.id != admin_id:
        return
    if not message.text:
        await message.reply("No text provided to broadcast")
        return
    with open("registered_users.txt", "r") as f:
        registered_users = f.read().splitlines()
    for user_id in registered_users:
        try:
            await bot.send_message(user_id, message.text.replace("/brod ", ""))
        except Exception as e:
            logging.error(f"Error while sending message to {user_id}: {e}")

@dp.message_handler(commands=['cmds', 'cmd', 'commands'], commands_prefix=PREFIX)
async def handle_cmds_cmd(message: types.Message):
    if await check_if_registered(message):
        await cmd1(message)

@dp.message_handler(commands=['id', 'info'], commands_prefix=PREFIX)
async def handle_id_cmd(message: types.Message):
    if await check_if_registered(message):
        await id1(message)

@dp.message_handler(commands=['sk'], commands_prefix=PREFIX)
async def handle_sk_cmd(message: types.Message):
    if await check_if_registered(message):
        await sk1(message)

@dp.message_handler(commands=['msk'], commands_prefix=PREFIX)
async def handle_msk_cmd(message: types.Message):
    if await check_if_registered(message):
        await msk1(message)

@dp.message_handler(commands=['skuser', 'apiskuser'], commands_prefix=PREFIX)
async def handle_skuser_cmd(message: types.Message):
    if await check_if_registered(message):
        await on_apiskuser(message)

@dp.message_handler(commands=['bin'], commands_prefix=PREFIX)
async def handle_bin_cmd(message: types.Message):
    if await check_if_registered(message):
        await bin1(message)

@dp.message_handler(commands=['rnd', 'rend', 'fake'], commands_prefix=PREFIX)
async def handle_rnd_cmd(message: types.Message):
    if await check_if_registered(message):
        await rnd1(message)
  
@dp.message_handler(commands=['ip'], commands_prefix=PREFIX)
async def handle_ip_cmd(message: types.Message):
    if await check_if_registered(message):
        await ip1(message)

@dp.message_handler(commands=['ai'], commands_prefix=PREFIX)
async def handle_ai_cmd(message: types.Message):
    if await check_if_registered(message):
        await ai1(message)

@dp.message_handler(commands=['ping'], commands_prefix=PREFIX)
async def handle_ping_cmd(message: types.Message):
    if await check_if_registered(message):
        await ping1(message)

@dp.message_handler(commands=['gen'], commands_prefix=PREFIX)
async def handle_ccgen_cmd(message: types.Message):
    if await check_if_registered(message):
        await generate_cc(message, bot)

@dp.message_handler(commands=['scr'], commands_prefix=PREFIX)
async def handle_scrape_cmd(message: types.Message):
    if await check_if_registered(message):
        await scrape1(message, bot, client)

@dp.message_handler(commands=['status'], commands_prefix=PREFIX)
async def handle_status_cmd(message: types.Message):
    if await check_if_registered(message):
        await status1(message)

@dp.message_handler(commands=['cc'], commands_prefix=PREFIX)
async def handle_cc_cmd(message: types.Message):
    if await check_if_registered(message):
        await cc1(message, bot)

if __name__ == "__main__":
    client.start()
    print("Bot Activated Successfully ✅")
    executor.start_polling(dp, skip_updates=True)