from telethon.sync import TelegramClient
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.errors.rpcerrorlist import UserAlreadyParticipantError, InviteHashExpiredError
import re
from pathlib import Path
import time

def getcards(text: str):
  """
    Parses a string input for credit card details and returns the card number, expiry date, and CVV code.

    Args:
        text (str): A string containing credit card details including the card number, expiry date, and CVV code.

    Returns:
        tuple: A tuple containing the card number, expiry date, and CVV code if valid, otherwise returns None for each value and an error message.

    Raises:
        None

    Examples:
        >>> getcards('CCNUM 4504400080699841 EXP 23/11 NAME Martin Kudlacek CVV 845')
        ('4504400080699841', '11', '2023', '845', None)

        >>> getcards('Invalid input')
        (None, None, None, None, 'Invalid input. Please provide all required details.')
    """

  input = re.findall(r"[0-9]+", text.replace('CVV2', ''))
  if not input or len(input) < 3:
    return None, None, None, None, 'invalid_input'

  if len(input) == 3:
    cc = input[0]
    if len(input[1]) == 3:
      mes = input[2][:2]
      ano = input[2][2:]
      cvv = input[1]
    else:
      mes = input[1][:2]
      ano = input[1][2:]
      cvv = input[2]
  else:
    cc = input[0]
    if len(input[1]) == 3:
      mes = input[2]
      ano = input[3]
      cvv = input[1]
    else:
      mes = input[1]
      ano = input[2]
      cvv = input[3]
    if len(mes) == 2 and (mes > '12' or mes < '01'):
      ano1 = mes
      mes = ano
      ano = ano1
  if cc[0] == 3 and len(cc) not in [15, 16] or int(cc[0]) not in [3, 4, 5, 6]:
    return None, None, None, None, "invalid_card_number"
  if len(mes) not in [
      2, 4
  ] or len(mes) == 2 and mes > '12' or len(mes) == 2 and mes < '01':
    return None, None, None, None, "invalid_card_month"
  if len(ano) not in [
      2, 4
  ] or len(ano) == 2 and ano < '23' or len(ano) == 4 and ano < '2023' or len(
      ano) == 2 and ano > '30' or len(ano) == 4 and ano > '2030':
    return None, None, None, None, "invalid_card_year"
  if cc[0] == 3 and len(cvv) != 4:
    return None, None, None, None, "invalid_card_cvv"

  if (cc, mes, ano, cvv):
    if len(ano) == 2:
      ano = "20" + str(ano)
    return cc, mes, ano, cvv, False

def extract_card_details(string):
    cards = re.findall(r'\b\d{15,16}\b', string)  # find all 15-16 digit numbers
    result = []
    ccs = []
    if len(cards) == 1:
        start = string.index(cards[0])  
        end = len(string) - 1
        text = string[start:end]
        cc,mes,ano,cvv,check = getcards(string)
        if cc in ccs:  return result
        ccs.append(cc)
        if not check: result.append([cc,mes,ano,cvv])
        return result   
    for i in range(1, len(cards)):
        card = cards[i]
        prev_card = cards[i-1]
        start = string.index(prev_card)  
        end = string.index(card)  
        text = string[start:end]  # text between previous card and current card
        cc,mes,ano,cvv,check  = getcards(text)
        print(text,cc,mes,ano,cvv,check)
        if cc in ccs:  continue
        ccs.append(cc)
        if not check: result.append([cc,mes,ano,cvv])
    return result

async def scrape1(message, bot, client):
    inp = ' '.join(message.text.split()[1:]).strip()
    print(inp)
    if len(inp) < 1:
        return await message.reply("INVALID INPUT")
    parts = inp.split()
    print(parts)
    if len(parts) < 2:
        await message.reply("INVALID INPUT")
        return
    channel, amount_str = parts
    print(channel)
    print(amount_str)
    if len(parts) < 2:
        await message.reply("INVALID INPUT")
        return
    channel, amount_str = parts
    if not (channel and amount_str):
        return await message.reply("INVALID INPUT")
    if 'joinchat' in channel:
        resolve = await client.resolve_invite_link(channel)
        if all(ele is None for ele in resolve):
            return await message.reply("INVALID LINK")
        else:
            chat_hash = re.findall('joinchat/(.*\w)', channel)
            if not chat_hash:
                return await message.reply("INVALID LINK")
            try:
                chat_invite = await client(ImportChatInviteRequest(chat_hash[0]))
            except UserAlreadyParticipantError:
                pass
            except InviteHashExpiredError:
                return await message.reply("LINK EXPIRED")
            except:
                return await message.reply("INVALID LINK")

    try:
        amount = int(amount_str)
    except:
        return await message.reply("INVALID INPUT")
    if amount > 2000 or amount < 1:
        return await message.reply("INVALID INPUT")
    try:
        ent = await client.get_entity(channel)
        if not ent:
            return await message.reply("INVALID CHAT")
    except:
        return await message.reply("INVALID CHAT")
    entType = ent.stringify().split('(')[0]
    if entType == 'User':
        return await message.reply("PRIVATE CHAT")
    ccs = []
    all_cards = []
    async for event in client.iter_messages(channel, limit=amount, wait_time=5 if amount > 1000 else 2):
        if not event.text:
            continue
        cards = extract_card_details(event.message)
        if cards:
            for card_det in cards:
                cc, mes, ano, cvv = card_det
                if cc in ccs:
                    continue
                ccs.append(cc)
                if len(mes) == 1:
                    mes = '0' + str(mes)
                if len(ano) == 2:
                    ano = '20' + str(ano)
                all_cards.append([cc, mes, ano, cvv])

    for cards in all_cards:
        cc, mes, ano, cvv = cards
        with open(f'{len(all_cards)}x{ent.username if ent.username else ""}.txt', 'a') as w:
            w.write(f'{cc}|{mes}|{ano}|{cvv}' + '\n')

    if len(all_cards) > 1:
        mess = f"""
<b>CC Scrapped Successfully</b> ✅

<b>Amount</b> : <code>{amount}</code> cards
<b>Source</b> : <code>{ent.username}</code>
<b>Skipped</b> : <code>{amount - len(all_cards)}</code> cards
<b>CC Found</b> : <code>{len(all_cards)}</code> cards

<b>Scrapped By</b> ➺ <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a>
<b>Bot Made By </b> ➺ <a href="tg://user?id=1408470031"><b>𝙰𝚂𝚃𝚁𝙾𝙱𝙾𝚈</b></a>
"""
        await bot.send_document(chat_id=message.chat.id, document=open(f'{len(all_cards)}x{ent.username if ent.username else ""}.txt', 'rb'), caption=mess, parse_mode='HTML')
        name = f'{len(all_cards)}x{ent.username if ent.username else ""}.txt'
        my_file = Path(name)
        my_file.unlink(missing_ok=True)
    else:
        return await message.reply("No Cards Found.")
