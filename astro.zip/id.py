async def id1(message):

  if message.reply_to_message:
    user_id = message.reply_to_message.from_user.id
    username = message.reply_to_message.from_user.username
    first = message.reply_to_message.from_user.first_name

  else:
    user_id = message.from_user.id
    username = message.from_user.username
    first = message.from_user.first_name

  user_id = user_id
  await message.answer(f'''
  
<b>TELEGRAM ID INFO</b>

<b>Hey</b> <a href="tg://user?id={user_id}">{first}</a>
<b>Your ID:</b> <code>{user_id}</code>
<b>Your Username:</b> @{username}
''', parse_mode="html")