from config import livemode

async def cmd1(message):
  if message.reply_to_message:
    user_id = message.reply_to_message.from_user.id
    first = message.reply_to_message.from_user.first_name
  else:
    user_id = message.from_user.id
    first = message.from_user.first_name

  await message.answer(f'''
<b>Dear {first} Here Is My Commands</b>

<b>Charge & Auth Gateways</b> ♻️

<b>STRIPE CHARGE</b> /cc [<code>{livemode}</code>]
<b>SHOPIFY CHARGE</b> /sc [<code>{livemode}</code>]
<b>BAINTREE AUTH</b> /au [<code>{livemode}</code>]

<b>Tools ⚙️</b>

<b>TELEGRAM ID INFO</b> /id
<b>BIN LOOK UP</b> /bin
<b>CC GENERATOR</b> /gen
<b>CC SCRAPER</b> /scr [<code>{livemode}</code>]
<b>IP LOOK UP</b> /ip
<b>ASK CHAT GPT</b> /ai
<b>BOT PING STATUS</b> /ping
<b>RANDOM INFO GENERATOR</b> /rnd
<b>SK KEY CHECK</b> /sk
<b>MASS SK KEY CHECK</b> /msk
<b>SK USER CHECK</b> /skuser

<b>Checked By</b> ➺ <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a>
<b>Bot Made By </b> ➺ <a href="tg://user?id=1408470031"><b>𝙰𝚂𝚃𝚁𝙾𝙱𝙾𝚈</b></a>
  ''', parse_mode="html")