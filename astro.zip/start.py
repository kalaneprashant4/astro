import time

async def start1(message):

  if message.reply_to_message:
    user_id = message.reply_to_message.from_user.id
    username = message.reply_to_message.from_user.username
    first = message.reply_to_message.from_user.first_name

  else:
    user_id = message.from_user.id
    username = message.from_user.username
    first = message.from_user.first_name

  user_id = user_id
  await message.answer(f'''
 
<b>👋 Hey</b> <a href="tg://user?id={user_id}">{first}</a><b> Welcome To Astronaut Bot</b>
<b>Your ID:</b> <code>{user_id}</code>
<b>Your Username:</b> @{username}
<b>To Know Bot Updates Join</b> <code><b>Astronaut Universe</b></code>
<b>To Start Using Me Hit /register</b>
<b>To Know My Commands Hit /cmds</b>
<b>Bot Made By</b> <a href="tg://user?id=1408470031"><b>𝙰𝚂𝚃𝚁𝙾𝙱𝙾𝚈</b></a>
''', parse_mode="html")