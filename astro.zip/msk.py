import re
import requests
import time
from requests.auth import HTTPBasicAuth
from aiogram import types

async def retrieve_balance(sk):
    bln = "https://api.stripe.com/v1/balance"
    auth = HTTPBasicAuth(sk, '')
    res = requests.get(bln, auth=auth)
    return res.json()

async def check_status(message, sk, tic):
    bal_dt = await retrieve_balance(sk)
    try:
        avl_bln = bal_dt['available'][0]['amount']
        pnd_bln = bal_dt['pending'][0]['amount']
        crn = bal_dt['available'][0]['currency']
    except KeyError:
        txtx = f"""
<b>SK :</b>
<code>{sk}</code>
<b>Result : </b>𝗦𝗞 𝗞𝗘𝗬 𝗥𝗘𝗩𝗢𝗞𝗘𝗗 ❌
        """
        return txtx, None, None

    tic = time.perf_counter()  # Start the timer

    chk = "https://api.stripe.com/v1/tokens"
    data = 'card[number]=4512238502012742&card[exp_month]=12&card[exp_year]=2023&card[cvc]=354'
    auth = HTTPBasicAuth(sk, '')
    rep = requests.post(chk, data=data, auth=auth)
    repp = rep.text

    if 'tok_' in repp:
        r_text = '𝗟𝗜𝗩𝗘 𝗞𝗘𝗬 ✅'
    elif 'Invalid API Key provided' in repp:
        r_text = "𝗜𝗡𝗩𝗔𝗟𝗜𝗗 𝗔𝗣𝗜 𝗞𝗘𝗬 𝗣𝗥𝗢𝗩𝗜𝗗𝗘𝗗 ❌"
    elif 'You did not provide an API key.' in repp:
        r_text = "𝗡𝗢 𝗦𝗞 𝗞𝗘𝗬 𝗣𝗥𝗢𝗩𝗜𝗗𝗘𝗗 ❌"
    elif 'rate_limit' in repp:
        r_text = "𝗥𝗔𝗧𝗘 𝗟𝗜𝗠𝗜𝗧 ⚠️"
    elif 'testmode_charges_only' in repp or 'test_mode_live_card' in repp:
        r_text = "𝗧𝗘𝗦𝗧 𝗠𝗢𝗗𝗘 𝗖𝗛𝗔𝗥𝗚𝗘 𝗢𝗡𝗟𝗬 ❌"
    elif 'api_key_expired' in repp:
        r_text = "𝗔𝗣𝗜 𝗞𝗘𝗬 𝗘𝗫𝗣𝗜𝗥𝗘𝗗 ❌"
    else:
        r_text = "𝗦𝗞 𝗞𝗘𝗬 𝗗𝗘𝗔𝗗 ❌"

    toc = time.perf_counter()  # Stop the timer
    txtxtx = f"""
<b>SK :</b>
<b><code>{sk}</code></b>
<b>Result :</b> {r_text}
<b>Currency : {crn}</b>
<b>Available Balance : {avl_bln}$</b>
<b>Pending Balance : {pnd_bln}$</b>
    """
    return txtxtx, tic, toc


async def msk1(message: types.Message):
    if len(message.text.split()) >= 2:
        sk_list = message.text.split()[1:]
    elif message.reply_to_message and message.reply_to_message.text:
        ttt = message.reply_to_message.text
        skm = re.finditer(r"sk_live_[a-zA-Z0-9]+", ttt)
        sk_list = [match.group(0) for match in skm]
    else:
        await message.answer("<b>NO SK KEY PROVIDED</b>\n<b>USE /sk [ YOUR SK KEY ]</b>", parse_mode="html")
        return

    response_message = "<code>CHECKING SK KEYS...</code>"

    # Send the initial response message and get the message ID
    sent_message = await message.answer(response_message, parse_mode="html")
    message_id = sent_message.message_id

    results = []
    tic = time.perf_counter()  # Start the timer

    for sk in sk_list:
        result, tic, toc = await check_status(message, sk, tic)
        results.append(result)

    checked_by = f"""
<b>Time Took : <code>{toc - tic:.2f}</code> Seconds</b>
<b>Checked By</b> ➺ <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a>"""

    response_message = ''.join(results) + f"\n{checked_by}"

    await message.bot.edit_message_text(chat_id=message.chat.id, message_id=message_id, text=response_message, parse_mode="html")
