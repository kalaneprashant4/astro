import re
import aiohttp

async def ip1(message):
    message_text = message.text.strip()
    ip = re.findall(r'[0-9]+(?:\.[0-9]+){3}', message_text)  # Extract the IP address from the message

    if not ip:
        await message.answer('<b>NO IP PROVIDED</b>\n<b>USE /ip [ YOUR IP ]</b>', parse_mode='html')
        return None

    url = f'https://spamx.id/ip/?ip={ip[0]}'  # Updated URL format with the first matched IP address

    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            if response.status != 200:
                await message.answer('Failed to fetch IP details')
                return None

            ip_details = await response.json()

    ip = ip_details.get('ip', '')
    city = ip_details.get("city", '')
    country = ip_details.get('country', '')
    region = ip_details.get('region', '')
    risk = ip_details.get('risk', '')
    score = ip_details.get('score', '')
    zip_code = ip_details.get('zip', '')

    await message.answer(f'''
<b>IP Address Look Up Successful</b> ✅
<b>
IP: <code>{ip}</code>
City: <code>{city}</code>
Country: <code>{country}</code>
Region: <code>{region}</code>
Risk: <code>{risk}</code>
Score: <code>{score}</code>
ZIP Code: <code>{zip_code}</code>
</b>
   ''', parse_mode="html")
